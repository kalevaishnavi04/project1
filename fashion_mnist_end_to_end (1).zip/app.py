
import streamlit as st
import tensorflow as tf
import numpy as np
from PIL import Image
import json

st.set_page_config(page_title="Fashion Item Classifier", page_icon="🧥", layout="centered")

# Load model and class names
@st.cache_resource
def load_model():
    return tf.keras.models.load_model("fashion_mnist_model.h5")

@st.cache_resource
def load_classes():
    try:
        with open("class_names.json", "r") as f:
            return json.load(f)
    except Exception:
        return ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
                'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']

model = load_model()
class_names = load_classes()

st.title("🧥 Fashion Item Classifier")
st.write("Upload a clothing image. The model will predict one of the 10 Fashion-MNIST classes.")

uploaded_file = st.file_uploader("Upload image", type=["png", "jpg", "jpeg"])

def preprocess_image(image: Image.Image):
    # Convert to grayscale, resize to 28x28, normalize to [0,1]
    img = image.convert('L').resize((28, 28))
    arr = np.array(img, dtype=np.float32) / 255.0
    arr = arr.reshape(1, 28, 28, 1)
    return arr, img

if uploaded_file is not None:
    image = Image.open(uploaded_file)
    arr, preview = preprocess_image(image)

    preds = model.predict(arr)
    probs = tf.nn.softmax(preds[0]).numpy()

    st.image(preview, caption="Preprocessed (28x28, grayscale)", width=200)
    pred_idx = int(np.argmax(probs))
    st.subheader(f"Prediction: {class_names[pred_idx]}")

    # Show top-3
    top3_idx = np.argsort(-probs)[:3]
    st.write("Top-3 predictions:")
    for i in top3_idx:
        st.write(f"- {class_names[int(i)]}: {probs[int(i)]:.3f}")

    # Bar chart of probabilities
    st.bar_chart(probs)
else:
    st.info("Please upload an image to get a prediction.")

st.caption("Model: Simple CNN trained on Fashion-MNIST; input images are converted to 28×28 grayscale.")
