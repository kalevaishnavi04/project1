
# Fashion MNIST End-to-End Project

## Components
- `Fashion_MNIST_End_to_End.ipynb` — training, evaluation, export
- `app.py` — Streamlit app for inference
- `requirements.txt` — dependencies

## Run the app
```bash
streamlit run app.py
```
